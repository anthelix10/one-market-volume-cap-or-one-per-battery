#!/usr/bin/env python3
"""Run and check the additional partition, capacity, netting and inventory analyses.

Uses the baseline inputs and forecasts without refitting. GBP outputs are
conditional model scores. Run from the extracted analysis directory:

    python code/run_additional_analyses.py --archive . --validate-stored
    python code/run_additional_analyses.py --archive . --tables --out tables
    python code/run_additional_analyses.py --archive . --out new_results

The first command reads paper_of_record/ without changing it. The second
reconstructs summary tables from daily records. The third re-solves dispatch;
its output directory must be empty. Parallel re-solving requires Linux/WSL.
"""
from __future__ import annotations
import os
for _key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ.setdefault(_key, '1')
import argparse, json, time, hashlib, platform, warnings, sys
from pathlib import Path
import multiprocessing as mp
import numpy as np
import pandas as pd
import scipy
from scipy import sparse
from scipy.optimize import linprog, milp, Bounds, LinearConstraint, OptimizeWarning
warnings.filterwarnings('ignore', category=OptimizeWarning, message='Unrecognized options detected.*')
D=.5; ETA=.93; N=48
POWER=np.array([98.,50.,49.]); BASE_E=np.array([196.,50.,24.5])
PARTS={'P|W|R':((0,),(1,),(2,)), 'PW|R':((0,1),(2,)),
       'PR|W':((0,2),(1,)), 'WR|P':((1,2),(0,)), 'PWR':((0,1,2),)}
NAMES=['Pillswood Battery Storage','Whitelee 1 Battery','Roosecote Battery']
_G={}

class Model:
    """Cumulative-state LP, matching the original partition routine's row order."""
    def __init__(self, part, energy=BASE_E, initial=.5, net=False):
        self.part=part; self.energy=np.asarray(energy,float); self.initial=float(initial); self.net=net
        self.g0=3*N; self.ec0=6*N; self.eg0=self.ec0+len(part)*N
        self.nv=6*N+2*len(part)*N
        rows=[];cols=[];vals=[];rhs=[];r=0
        for i in range(3):
            for t in range(1,N+1):
                for sign,lim in ((1., self.energy[i]*(1-initial)),(-1.,self.energy[i]*initial)):
                    for k in range(t):
                        rows.extend([r,r]);cols.extend([i*N+k,self.g0+i*N+k]);vals.extend([sign*ETA*D,-sign*D/ETA])
                    rhs.append(lim);r+=1
        self.caprows=[]
        for j,group in enumerate(part):
            for t in range(N):
                for side in (0,1):
                    for i in group:
                        if net:
                            rows.extend([r,r]);cols.extend([i*N+t,self.g0+i*N+t]);vals.extend([1. if side==0 else -1.,-1. if side==0 else 1.])
                        else:
                            rows.append(r);cols.append((i*N+t) if side==0 else self.g0+i*N+t);vals.append(1.)
                    rows.append(r);cols.append((self.ec0 if side==0 else self.eg0)+j*N+t);vals.append(-1.)
                    rhs.append(0.);self.caprows.append(r);r+=1
        self.aub=sparse.csr_matrix((vals,(rows,cols)),shape=(r,self.nv));self.rhs=np.array(rhs)
        er=[];ec=[];ev=[]
        for i in range(3):
            for t in range(N):
                er.extend([i,i]);ec.extend([i*N+t,self.g0+i*N+t]);ev.extend([ETA*D,-D/ETA])
        self.aeq=sparse.csr_matrix((ev,(er,ec)),shape=(3,self.nv))
        self.ub=np.r_[np.repeat(POWER,N), np.repeat(POWER,N), np.repeat(np.inf,2*len(part)*N)]
        self.bounds=list(zip(np.zeros(self.nv),self.ub))
    def problem(self, f,v,rho,phi):
        obj=np.r_[np.tile(D*f,3),np.tile(-D*f,3),np.repeat(phi*D,2*len(self.part)*N)]
        b=self.rhs.copy(); caps=np.concatenate([np.repeat(np.minimum(POWER[list(g)].sum(),rho*v/D),2) for g in self.part]);b[self.caprows]=caps
        return obj,b
    def solve(self,f,v,rho=.02,phi=30.,binary=False):
        obj,b=self.problem(f,v,rho,phi)
        if not binary:
            res=linprog(obj,A_ub=self.aub,b_ub=b,A_eq=self.aeq,b_eq=np.zeros(3),bounds=self.bounds,
                        method='highs',options={'presolve':True,'threads':1})
        else:
            # Per asset-period binary y: c <= P*y; g <= P*(1-y).
            z=3*N;rows=[];cols=[];vals=[];br=[]
            for i in range(3):
                for t in range(N):
                    r=2*(i*N+t);zi=self.nv+i*N+t
                    rows.extend([r,r,r+1,r+1]);cols.extend([i*N+t,zi,self.g0+i*N+t,zi]);vals.extend([1.,-POWER[i],1.,POWER[i]])
                    br.extend([0.,POWER[i]])
            binA=sparse.csr_matrix((vals,(rows,cols)),shape=(2*z,self.nv+z))
            a=sparse.vstack([sparse.hstack([self.aub,sparse.csr_matrix((self.aub.shape[0],z))]),
                             sparse.hstack([self.aeq,sparse.csr_matrix((3,z))]),binA],format='csc')
            lo=np.r_[np.repeat(-np.inf,len(b)),np.zeros(3),np.repeat(-np.inf,2*z)]
            hi=np.r_[b,np.zeros(3),br]
            with warnings.catch_warnings():
                warnings.simplefilter('ignore', RuntimeWarning)
                res=milp(np.r_[obj,np.zeros(z)],integrality=np.r_[np.zeros(self.nv),np.ones(z)],
                         bounds=Bounds(np.zeros(self.nv+z),np.r_[self.ub,np.ones(z)]),
                         constraints=LinearConstraint(a,lo,hi),
                         options={'mip_rel_gap':1e-9,'time_limit':180.,'presolve':True,'threads':1})
        if not res.success:
            raise RuntimeError(f'Optimisation failed: {res.message}')
        c=res.x[:3*N].reshape(3,N);g=res.x[self.g0:self.g0+3*N].reshape(3,N)
        check=feasibility(c,g,self.energy,self.initial)
        if check['max_violation']>1e-5: raise RuntimeError(f'Physical infeasibility {check}')
        if binary and np.minimum(c,g).max()>1e-5: raise RuntimeError('MILP overlap')
        return c,g,-float(res.fun), float(getattr(res,'mip_gap',0.) or 0.)

def feasibility(c,g,energy=BASE_E,initial=.5):
    s=np.c_[np.zeros(3),np.cumsum(D*(ETA*c-g/ETA),axis=1)]+np.asarray(energy)[:,None]*initial
    v=max(0.,float(-c.min()),float(-g.min()),float(np.max(c-POWER[:,None])),float(np.max(g-POWER[:,None])),float(-s.min()),float(np.max(s-np.asarray(energy)[:,None])),float(np.max(abs(s[:,-1]-np.asarray(energy)*initial))))
    return {'max_violation':v,'terminal_residual_mwh':float(np.max(abs(s[:,-1]-np.asarray(energy)*initial))), 'overlap_periods':int(np.sum(np.minimum(c,g)>1e-7))}

def audit(c,g,p,v,part,rho=.02,phi=30.,net=False):
    gross=float(np.sum(D*p[None,:]*(g-c)));ex=0.
    for group in part:
        cap=np.minimum(POWER[list(group)].sum(),rho*v/D)
        gc=c[list(group)].sum(axis=0);gg=g[list(group)].sum(axis=0)
        if net: ex+=float(D*np.maximum(abs(gg-gc)-cap,0.).sum())
        else: ex+=float(D*(np.maximum(gc-cap,0.)+np.maximum(gg-cap,0.)).sum())
    return {'gross_gbp':gross,'excess_mwh':ex,'score_gbp':gross-phi*ex,'throughput_mwh':float(D*(c+g).sum())}

def load(root):
    out=root/'paper_of_record'; dat=pd.read_csv(out/'matched_dates_1081.csv');dates=pd.DatetimeIndex(pd.to_datetime(dat.iloc[:,0]))
    a={ 'dates':dates.strftime('%Y-%m-%d').to_numpy() }
    code_path = str((root / 'code').resolve())
    if code_path not in sys.path:
        sys.path.insert(0, code_path)
    from run_paper_of_record import load_market_inputs
    panels = load_market_inputs(root, out)
    for key, panel in [('p', 'price'), ('v', 'volume'), ('sv', 'sched_volume')]:
        a[key] = panels[panel].loc[dates, [str(i) for i in range(1, N+1)]].to_numpy(float)
    df=pd.read_csv(out/'forecast_base_ridge_period.csv',parse_dates=['date']);a['f']=df.pivot(index='date',columns='period',values='forecast_price').loc[dates,list(range(1,N+1))].to_numpy(float)
    df=pd.read_csv(out/'controller_period_schedules_1081.csv.gz',parse_dates=['date'])
    for key,label in [('per','Per-unit priced'),('agg','Shared priced')]:
        a[key+'c']=np.zeros((len(dates),3,N)); a[key+'g']=np.zeros((len(dates),3,N))
        for i,name in enumerate(NAMES):
            d=df[(df.schedule==label)&(df.asset==name)].sort_values(['date','settlement_period'])
            a[key+'c'][:,i]=d.charge_mw.to_numpy().reshape(len(dates),N);a[key+'g'][:,i]=d.discharge_mw.to_numpy().reshape(len(dates),N)
    if len(dates) != 1081 or dates.has_duplicates or not dates.is_monotonic_increasing:
        raise ValueError('Expected 1,081 unique chronological matched dates')
    for key in ('p', 'v', 'sv', 'f'):
        if a[key].shape != (1081, N) or not np.isfinite(a[key]).all():
            raise ValueError(f'Invalid finite input matrix: {key}')
    if (a['v'] < 0).any() or (a['sv'] < 0).any():
        raise ValueError('Volume inputs must be non-negative')
    return a

def work(task):
    family,label,settings,ids=task
    rho=settings.get('rho',.02);phi=settings.get('phi',30.);net=settings.get('net',False)
    energy=np.array([196.,50.,settings.get('roosecote_mwh',24.5)]); initial=settings.get('initial',.5)
    model=Model(PARTS[label],energy,initial,net); rows=[]
    for k in ids:
        c,g,obj,gap=model.solve(_G['f'][k],_G['sv'][k],rho,phi)
        m=audit(c,g,_G['p'][k],_G['v'][k],PARTS[label],rho,phi,net)
        check=feasibility(c,g,energy,initial)
        row=dict(family=family,partition=label,date=_G['dates'][k],rho=rho,phi=phi,roosecote_mwh=energy[2],initial=initial,net=net,forecast_objective_gbp=obj,**m,**check)
        # Common gross audit and fixed original schedule net/gross comparisons.
        row['common_gross_score_gbp']=audit(c,g,_G['p'][k],_G['v'][k],PARTS[label],rho,phi,False)['score_gbp']
        row['fixed_reference_score_gbp']=audit(_G['perc'][k],_G['perg'][k],_G['p'][k],_G['v'][k],PARTS[label],rho,phi,net)['score_gbp']
        checked = family in ('netting', 'capacity', 'boundary')
        performed = checked and check['overlap_periods'] > 0
        row['binary_checked'] = checked
        row['binary_solve_performed'] = performed
        row['binary_result_source'] = ('binary_resolve' if performed else 'lp_feasible' if checked else 'not_checked')
        if performed:
            cc,gg,oo,mg=model.solve(_G['f'][k],_G['sv'][k],rho,phi,True)
            row['binary_score_gbp']=audit(cc,gg,_G['p'][k],_G['v'][k],PARTS[label],rho,phi,net)['score_gbp'];row['binary_forecast_objective_gbp']=oo;row['mip_gap']=mg
            row['binary_max_violation']=feasibility(cc,gg,energy,initial)['max_violation']
        elif checked:
            # An overlap-free LP optimum is feasible and optimal in the restricted model.
            row['binary_score_gbp']=row['score_gbp'];row['binary_forecast_objective_gbp']=obj;row['mip_gap']=0.;row['binary_max_violation']=check['max_violation']
        else:
            # A missing test is not a binary result. Blank numeric fields in CSV.
            for field in ('binary_score_gbp', 'binary_forecast_objective_gbp', 'mip_gap', 'binary_max_violation'):
                row[field] = np.nan
        rows.append(row)
    return rows

def complementarity(out):
    allrows=[]; periods=[]; models={'per':Model(PARTS['P|W|R']),'agg':Model(PARTS['PWR'])}
    for key,label in [('per','P|W|R'),('agg','PWR')]:
        for k,date in enumerate(_G['dates']):
            c=_G[key+'c'][k];g=_G[key+'g'][k];m=audit(c,g,_G['p'][k],_G['v'][k],PARTS[label]); flags=feasibility(c,g)['overlap_periods'];model=models[key]
            original_obj=audit(c,g,_G['f'][k],_G['sv'][k],PARTS[label])['score_gbp']
            if flags:
                cc,gg,obj,gap=model.solve(_G['f'][k],_G['sv'][k],binary=True)
                for i in range(3):
                    for t in range(N): periods.append(dict(schedule=key,date=date,asset=NAMES[i],period=t+1,charge_mw=cc[i,t],discharge_mw=gg[i,t]))
            else: cc,gg,obj,gap=c,g,original_obj,0.
            new=audit(cc,gg,_G['p'][k],_G['v'][k],PARTS[label]);common=audit(cc,gg,_G['p'][k],_G['v'][k],PARTS['PWR']);chk=feasibility(cc,gg)
            # Deleting matched c/g changes stored energy; record original invalid terminal shift.
            overlap=np.minimum(c,g);delete=feasibility(c-overlap,g-overlap)
            allrows.append(dict(schedule=key,date=date,binary_checked=True,binary_solve_performed=bool(flags),binary_result_source='binary_resolve' if flags else 'lp_feasible',original_score_gbp=m['score_gbp'],original_objective_gbp=original_obj,binary_score_gbp=new['score_gbp'],binary_gross_gbp=new['gross_gbp'],binary_aggregate_audit_score_gbp=common['score_gbp'],binary_throughput_mwh=new['throughput_mwh'],binary_objective_gbp=obj,original_overlap_periods=flags,mip_gap=gap,deleted_overlap_terminal_error_mwh=delete['terminal_residual_mwh'],**chk))
    df=pd.DataFrame(allrows);df.to_csv(out/'complementarity_daily.csv',index=False);pd.DataFrame(periods).to_csv(out/'complementarity_replacement_periods.csv',index=False)
    summary=df.groupby('schedule',as_index=False).agg(original_score_gbp=('original_score_gbp','sum'),binary_score_gbp=('binary_score_gbp','sum'),binary_gross_gbp=('binary_gross_gbp','sum'),binary_aggregate_audit_score_gbp=('binary_aggregate_audit_score_gbp','sum'),binary_throughput_mwh_day=('binary_throughput_mwh','mean'),original_overlap_periods=('original_overlap_periods','sum'),original_overlap_days=('original_overlap_periods',lambda s:int((s>0).sum())),binary_solve_days=('binary_solve_performed','sum'),max_physical_violation=('max_violation','max'),max_mip_gap=('mip_gap','max'),max_deleted_overlap_terminal_error_mwh=('deleted_overlap_terminal_error_mwh','max'))
    summary.to_csv(out/'complementarity_summary.csv',index=False)
    print('COMPLEMENTARITY\n',summary.to_string(index=False),flush=True)

def summarise(df):
    keys=['family','partition','rho','phi','roosecote_mwh','initial','net']
    return df.groupby(keys,as_index=False).agg(days=('date','size'),gross_gbp=('gross_gbp','sum'),score_gbp=('score_gbp','sum'),excess_mwh=('excess_mwh','sum'),throughput_mwh_day=('throughput_mwh','mean'),forecast_objective_gbp=('forecast_objective_gbp','sum'),common_gross_score_gbp=('common_gross_score_gbp','sum'),fixed_reference_score_gbp=('fixed_reference_score_gbp','sum'),binary_score_gbp=('binary_score_gbp',lambda s:s.sum(min_count=1)),binary_forecast_objective_gbp=('binary_forecast_objective_gbp',lambda s:s.sum(min_count=1)),binary_checked=('binary_checked','all'),binary_solve_performed=('binary_solve_performed','any'),binary_solve_days=('binary_solve_performed','sum'),binary_checked_days=('binary_checked','sum'),overlap_periods=('overlap_periods','sum'),overlap_days=('overlap_periods',lambda s:int((s>0).sum())),max_violation=('max_violation','max'),max_binary_violation=('binary_max_violation','max'),max_mip_gap=('mip_gap','max'))

def run_experiments(args, p):
    if args.surface_only and args.sens_only:
        p.error('--surface-only and --sens-only cannot be combined')
    if args.workers < 1:
        p.error('--workers must be at least one')
    if args.out.exists() and any(args.out.iterdir()):
        p.error('Output directory must be empty; use a new directory to protect retained results')
    if 'fork' not in mp.get_all_start_methods():
        p.error('This release is tested on Linux/WSL and requires the fork start method')
    args.out.mkdir(parents=True,exist_ok=True);global _G;_G=load(args.archive)
    t=time.time();tasks=[]
    if not args.surface_only:
        complementarity(args.out)
        for e in (24.5,49.,98.):
            for name in PARTS:
                for start in range(0,len(_G['dates']),80):tasks.append(('capacity',name,{'roosecote_mwh':e},range(start,min(start+80,len(_G['dates'])))))
        for name in PARTS:
            for start in range(0,len(_G['dates']),80):tasks.append(('netting',name,{'net':True},range(start,min(start+80,len(_G['dates'])))))
        for initial in (.25,.75):
            for name in ('P|W|R','PWR'):
                for start in range(0,len(_G['dates']),80):tasks.append(('boundary',name,{'initial':initial},range(start,min(start+80,len(_G['dates'])))))
    if not args.sens_only:
        for rho in (.005,.01,.02,.03,.05):
            for phi in (10.,20.,30.,45.,60.):
                for name in ('PW|R','PR|W','WR|P'):
                    for start in range(0,len(_G['dates']),80):tasks.append(('surface',name,{'rho':rho,'phi':phi},range(start,min(start+80,len(_G['dates'])))))
    print(f'Start {len(tasks)} chunks; workers={args.workers}',flush=True)
    target=args.out/('daily_surface.csv' if args.surface_only else 'daily_sensitivities.csv' if args.sens_only else 'additional_daily.csv')
    ctx=mp.get_context('fork');done=0
    with ctx.Pool(args.workers,maxtasksperchild=3) as pool:
        for rows in pool.imap_unordered(work,tasks,chunksize=1):
            pd.DataFrame(rows).to_csv(target,mode='w' if done==0 else 'a',header=(done==0),index=False)
            done+=1
            if done%10==0 or done==len(tasks):print(f'{done}/{len(tasks)} chunks; {time.time()-t:.1f}s',flush=True)
    df=pd.read_csv(target)
    expected_settings = 75 if args.surface_only else 24 if args.sens_only else 99
    keys = ['family','partition','rho','phi','roosecote_mwh','initial','net']
    counts = df.groupby(keys).size()
    if len(counts) != expected_settings or not (counts == 1081).all() or df.duplicated(keys+['date']).any():
        raise RuntimeError('Incomplete or duplicated setting-day output')
    if float((df.gross_gbp - df.phi*df.excess_mwh - df.score_gbp).abs().max()) > 1e-7:
        raise RuntimeError('Score identity failed')
    if not df.loc[df.family == 'surface', ['binary_score_gbp','binary_forecast_objective_gbp','mip_gap','binary_max_violation']].isna().all().all():
        raise RuntimeError('Unchecked surface contains apparent binary results')
    tested = df[df.binary_checked]
    if not (tested.binary_forecast_objective_gbp <= tested.forecast_objective_gbp + 1e-6).all():
        raise RuntimeError('Binary forecast objective exceeds LP optimum')
    df = df.sort_values(keys+['date']).reset_index(drop=True)
    df.to_csv(str(target)+'.gz', index=False, compression={'method':'gzip','mtime':0})
    target.unlink()
    summarise(df).to_csv(args.out/target.name.replace('daily','summary'),index=False)
    report={'status':'PASS','rows':len(df),'settings':len(summarise(df)),'days':len(_G['dates']),'max_physical_violation':float(df.max_violation.max()),'max_binary_violation':float(df.binary_max_violation.max()) if df.binary_max_violation.notna().any() else None,'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'elapsed_s':time.time()-t,'archive':'. (the --archive input; absolute machine path omitted)','input_sha256':{str(q.relative_to(args.archive)):hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted((args.archive/'paper_of_record').iterdir()) if q.is_file() and (q.suffix == '.csv' or q.name.endswith('.csv.gz'))},'binary_field_policy':'Unchecked surface rows have blank binary numeric fields, binary_checked=false and binary_solve_performed=false. Overlap-free sensitivity LP optima are labelled lp_feasible; only binary_resolve means a MILP was run.', 'notes':['No new forecast fitting or tuning.','Scheduling uses lagged volume only.','The surface uses LP relaxation; capacity/netting/boundary include exact binary re-solves on days where the LP returned overlap.','Unflagged LP schedules are feasible for the corresponding MILP.','Fixed-reference columns on the surface always use the original rho=.02 phi=30 per-asset schedule; they are NOT parameter-specific reoptimised accounting decompositions.']}
    (args.out/target.name.replace('daily','validation').replace('.csv','.json')).write_text(json.dumps(report,indent=2,allow_nan=False))
    print(json.dumps({k:v for k,v in report.items() if k!='input_sha256'},indent=2),flush=True)



KEYS = ['family', 'partition', 'rho', 'phi', 'roosecote_mwh', 'initial', 'net']
LABELS = ['P|W|R', 'PW|R', 'PR|W', 'WR|P', 'PWR']
BASE_LABELS = dict(zip([
    'Pillswood | Whitelee | Roosecote', 'Pillswood+Whitelee | Roosecote',
    'Pillswood+Roosecote | Whitelee', 'Whitelee+Roosecote | Pillswood',
    'Pillswood+Whitelee+Roosecote'], LABELS))


def require(condition: bool, message: str) -> None:
    if not bool(condition):
        raise ValueError(message)


def as_bool(series: pd.Series) -> pd.Series:
    if series.dtype == bool:
        return series
    result = series.astype(str).str.lower().map({'true': True, 'false': False})
    require(result.notna().all(), f'Invalid Boolean values in {series.name}')
    return result.astype(bool)


def validate(summary: pd.DataFrame, daily: pd.DataFrame, matched: set[str]) -> dict:
    require(len(summary) == 99 and len(daily) == 107019, 'Unexpected scenario coverage')
    require(not daily.duplicated(KEYS + ['date']).any(), 'Duplicate setting-day keys')
    require(not summary.duplicated(KEYS).any(), 'Duplicate summary keys')
    for frame in (daily, summary):
        for name in ('net', 'binary_checked', 'binary_solve_performed'):
            frame[name] = as_bool(frame[name])
    groups = daily.groupby(KEYS, sort=True)
    for key, rows in groups:
        require(len(rows) == 1081 and set(rows.date) == matched, f'Incomplete dates: {key}')
    require((summary.days == 1081).all(), 'Incomplete summary coverage')
    expected_rows = {'surface': 81075, 'capacity': 16215, 'netting': 5405, 'boundary': 4324}
    require(daily.groupby('family').size().to_dict() == expected_rows, 'Unexpected families')
    for name in ('gross_gbp', 'score_gbp', 'excess_mwh', 'forecast_objective_gbp',
                 'throughput_mwh', 'max_violation'):
        require(np.isfinite(daily[name]).all(), f'Nonfinite required field {name}')
    score_error = float((daily.gross_gbp - daily.phi * daily.excess_mwh - daily.score_gbp).abs().max())
    require(score_error < 1e-7, 'Daily conditional-score identity failed')
    require(daily.max_violation.max() < 1e-7, 'LP physical residual exceeds tolerance')
    tested = daily[daily.family != 'surface']
    surface = daily[daily.family == 'surface']
    binary_fields = ['binary_score_gbp', 'binary_forecast_objective_gbp', 'mip_gap', 'binary_max_violation']
    require(surface[binary_fields].isna().all().all(), 'Unchecked surface has apparent binary results')
    require((~surface.binary_checked & ~surface.binary_solve_performed).all(), 'Surface Boolean flags')
    require(surface.binary_result_source.eq('not_checked').all(), 'Surface provenance labels')
    require(tested.binary_checked.all(), 'Sensitivity binary checks missing')
    require(np.isfinite(tested[binary_fields]).all().all(), 'Missing checked binary result')
    require((tested.binary_solve_performed == (tested.overlap_periods > 0)).all(), 'MILP execution flags')
    require(tested.loc[tested.binary_solve_performed, 'binary_result_source'].eq('binary_resolve').all(), 'MILP labels')
    require(tested.loc[~tested.binary_solve_performed, 'binary_result_source'].eq('lp_feasible').all(), 'LP reuse labels')
    require((tested.binary_forecast_objective_gbp <= tested.forecast_objective_gbp + 1e-6).all(), 'Binary objective exceeds LP')
    require(tested.binary_max_violation.max() < 1e-7, 'Binary physical residual exceeds tolerance')
    net = daily[daily.family == 'netting']
    require((net.score_gbp >= net.common_gross_score_gbp - 1e-7).all(), 'Fixed net versus gross audit failed')
    ssurface = summary[summary.family == 'surface']
    require(ssurface[['binary_score_gbp', 'binary_forecast_objective_gbp', 'max_binary_violation', 'max_mip_gap']].isna().all().all(), 'Unchecked binary summary must be blank')
    require((~ssurface.binary_checked & ~ssurface.binary_solve_performed).all(), 'Surface summary flags')
    # Independently aggregate daily numbers, without importing the solver's summariser.
    maximum = 0.0
    index = summary.set_index(KEYS)
    require(set(groups.groups) == set(index.index), 'Daily/summary keys differ')
    for key, rows in groups:
        stored = index.loc[key]
        for name in ['gross_gbp','score_gbp','excess_mwh','forecast_objective_gbp',
                     'common_gross_score_gbp','fixed_reference_score_gbp',
                     'binary_score_gbp','binary_forecast_objective_gbp']:
            calculated = rows[name].sum(min_count=1)
            actual = stored[name]
            if pd.isna(calculated):
                require(pd.isna(actual), f'{key}: {name} not blank')
            else:
                difference = abs(float(calculated) - float(actual))
                maximum = max(maximum, difference)
                require(difference <= 1e-6 + 1e-12 * abs(float(actual)), f'{key}: summary {name}')
        require(abs(rows.throughput_mwh.mean() - stored.throughput_mwh_day) < 1e-7, 'Throughput summary mismatch')
        require(int(rows.binary_solve_performed.sum()) == int(stored.binary_solve_days), 'MILP day counts')
        require(int(rows.binary_checked.sum()) == int(stored.binary_checked_days), 'Checked day counts')
    return {'status':'PASS','settings':99,'daily_rows':107019,
            'no_duplicate_daily_keys':True,'all_settings_1081_days':True,
            'score_identity_max_error_gbp':score_error,
            'daily_to_summary_max_abs_error':maximum,
            'unchecked_binary_fields_blank':True,
            'binary_execution_flags_checked':True,
            'net_same_schedule_score_at_least_gross':True,
            'binary_forecast_objective_not_above_lp':True,
            'max_milp_reported_gap':float(tested.mip_gap.max())}


def build(archive: Path, results: Path, out: Path | None = None) -> dict:
    por = archive / 'paper_of_record'
    candidates = [results/name for name in ('additional_daily.csv.gz', 'additional_daily.csv',
                                            'daily_all.csv.gz', 'daily_all.csv')]
    daily_path = next((path for path in candidates if path.is_file()), None)
    require(daily_path is not None, 'Additional daily results are missing')
    d = pd.read_csv(daily_path)
    s = summarise(d)
    matched = set(pd.read_csv(por/'matched_dates_1081.csv').iloc[:,0].astype(str))
    checks = validate(s,d,matched)
    e = pd.read_csv(por/'cap_assignment_surface_25_cells.csv')
    cd = pd.read_csv(results/'complementarity_daily.csv')
    replacement = pd.read_csv(results/'complementarity_replacement_periods.csv')
    checks.update(validate_reference_records(archive, cd, replacement))
    c = summarise_complementarity(cd).set_index('schedule')
    require(set(c.index) == {'per','agg'}, 'Reference complementarity endpoints missing')
    grid = []
    for _, r in e.iterrows():
        row = {'rho_pct':r.rho*100,'phi_gbp_mwh':r.phi_gbp_mwh,
               'P|W|R':r.per_unit_priced_per_unit_score_gbp,'PWR':r.shared_priced_score_gbp}
        for label in LABELS[1:4]:
            candidates = s[(s.family=='surface') & (s.partition==label) & np.isclose(s.rho,r.rho) & np.isclose(s.phi,r.phi_gbp_mwh)]
            require(len(candidates)==1, 'Missing or ambiguous partition surface cell')
            row[label] = float(candidates.iloc[0].score_gbp)
        grid.append(row)
    grid = pd.DataFrame(grid)[['rho_pct','phi_gbp_mwh']+LABELS].sort_values(['rho_pct','phi_gbp_mwh'])
    require(len(grid)==25 and not grid.duplicated(['rho_pct','phi_gbp_mwh']).any(), 'Incomplete 125-score grid')
    base = s[(s.family=='capacity') & np.isclose(s.roosecote_mwh,24.5)].set_index('partition')
    original = pd.read_csv(por/'partition_assignment_summary.csv')
    deltas = {}
    for _, r in original.iterrows():
        label = BASE_LABELS[r.partition]
        deltas[label] = abs(float(base.loc[label,'score_gbp']) - float(r.optimised_score_gbp))
    require(len(deltas)==5 and max(deltas.values()) < 1e-6, 'Reference scores do not reproduce the baseline')
    checks['all_five_reference_scores_match_original_max_difference_gbp'] = max(deltas.values())
    cap = s[s.family=='capacity'].pivot(index='roosecote_mwh',columns='partition',values='score_gbp')[LABELS]
    cap['endpoint_gap'] = cap['P|W|R']-cap.PWR
    net = s[s.family=='netting'].set_index('partition').reindex(LABELS)
    boundary = s[s.family=='boundary'].pivot(index='initial',columns='partition',values='score_gbp')
    for label in ('PWR','P|W|R'):
        boundary.loc[.5,label] = base.loc[label,'score_gbp']
    boundary = boundary.sort_index(); boundary['gap'] = boundary['P|W|R']-boundary.PWR
    metrics = {
        'original_endpoint_gap':c.loc['per','original_score_gbp']-c.loc['agg','original_score_gbp'],
        'binary_endpoint_gap':c.loc['per','binary_score_gbp']-c.loc['agg','binary_score_gbp'],
        'binary_accounting_gap':c.loc['per','binary_score_gbp']-c.loc['per','binary_aggregate_audit_score_gbp'],
        'binary_recovery':c.loc['agg','binary_score_gbp']-c.loc['per','binary_aggregate_audit_score_gbp'],
        'net_aggregate_change_lp':net.loc['PWR','score_gbp']-base.loc['PWR','score_gbp'],
        'net_endpoint_gap_lp':net.loc['P|W|R','score_gbp']-net.loc['PWR','score_gbp'],
        'net_endpoint_gap_binary':net.loc['P|W|R','binary_score_gbp']-net.loc['PWR','binary_score_gbp'],
        'net_aggregate_change_binary':net.loc['PWR','binary_score_gbp']-base.loc['PWR','binary_score_gbp'],
        'net_fixed_original_aggregate_change':net.loc['PWR','fixed_reference_score_gbp']-base.loc['PWR','fixed_reference_score_gbp'],
        'grid_all_intermediate_between_endpoints':bool(((grid[LABELS[1:4]].min(axis=1)>=grid.PWR-1e-5)&(grid[LABELS[1:4]].max(axis=1)<=grid['P|W|R']+1e-5)).all()),
        'grid_intermediate_ranking_WR_PR_PW_all':bool(((grid['WR|P']>=grid['PR|W'])&(grid['PR|W']>=grid['PW|R'])).all()),
        'grid_max_group_spread':float((grid[LABELS[1:4]].max(axis=1)-grid[LABELS[1:4]].min(axis=1)).max()),
        'grid_min_group_spread':float((grid[LABELS[1:4]].max(axis=1)-grid[LABELS[1:4]].min(axis=1)).min()),
        'settings':99,'daily_rows':107019,'validation':'PASS'}
    for key in ('per','agg'):
        metrics[key+'_binary_change'] = c.loc[key,'binary_score_gbp']-c.loc[key,'original_score_gbp']
        metrics[key+'_binary_change_pct'] = (c.loc[key,'binary_score_gbp']/c.loc[key,'original_score_gbp']-1)*100
        metrics[key+'_overlap_pct_asset_periods'] = 100*c.loc[key,'original_overlap_periods']/(1081*48*3)
    metrics['binary_gap_change'] = metrics['binary_endpoint_gap']-metrics['original_endpoint_gap']
    checks['all_intermediate_grid_scores_between_endpoints'] = metrics['grid_all_intermediate_between_endpoints']
    f = pd.read_csv(por/'pn_b1610_physical_feasibility_daily_1081.csv')
    for name in ('feasible_for_some_initial_soc','feasible_from_50pct_soc','power_rating_exceeded'):
        f[name] = as_bool(f[name])
    f['joint_energy_power'] = f.feasible_for_some_initial_soc & ~f.power_rating_exceeded
    operational = f.groupby(['series','asset']).agg(days=('date','size'),energy_only=('feasible_for_some_initial_soc','mean'),from_50_energy_only=('feasible_from_50pct_soc','mean'),joint_energy_power=('joint_energy_power','mean'),power_exceedance_days=('power_rating_exceeded','sum')).reset_index()
    checks['key_metrics'] = metrics
    if out is not None:
        out.mkdir(parents=True,exist_ok=True)
        grid.to_csv(out/'all_five_partitions_25_settings_gbp.csv',index=False)
        for label in LABELS[1:4]:
            s[(s.family=='surface') & (s.partition==label)].sort_values(['rho','phi']).to_csv(out/('surface_'+label.replace('|','_')+'.csv'),index=False)
        cap.to_csv(out/'capacity_scores.csv'); net.to_csv(out/'netting_cross_audit.csv')
        boundary.to_csv(out/'boundary_scores.csv');operational.to_csv(out/'operational_energy_power_screen.csv',index=False)
        (out/'key_metrics.json').write_text(json.dumps(metrics,indent=2,allow_nan=False)+'\n',encoding='utf-8')
        (out/'independent_postprocessing_checks.json').write_text(json.dumps(checks,indent=2,allow_nan=False)+'\n',encoding='utf-8')
        s.to_csv(out/'additional_summary.csv',index=False)
        c.reset_index().to_csv(out/'complementarity_summary.csv',index=False)
    return checks




def summarise_complementarity(df: pd.DataFrame) -> pd.DataFrame:
    return df.groupby('schedule',as_index=False).agg(
        original_score_gbp=('original_score_gbp','sum'),
        binary_score_gbp=('binary_score_gbp','sum'),
        binary_gross_gbp=('binary_gross_gbp','sum'),
        binary_aggregate_audit_score_gbp=('binary_aggregate_audit_score_gbp','sum'),
        binary_throughput_mwh_day=('binary_throughput_mwh','mean'),
        original_overlap_periods=('original_overlap_periods','sum'),
        original_overlap_days=('original_overlap_periods',lambda x:int((x>0).sum())),
        binary_solve_days=('binary_solve_performed','sum'),
        max_physical_violation=('max_violation','max'),
        max_mip_gap=('mip_gap','max'),
        max_deleted_overlap_terminal_error_mwh=('deleted_overlap_terminal_error_mwh','max'))


def validate_reference_records(archive: Path, rows: pd.DataFrame,
                               replacement: pd.DataFrame) -> dict:
    require(len(rows)==2162, 'Incomplete reference comparison')
    require(not rows.duplicated(['schedule','date']).any(), 'Duplicate reference daily keys')
    for key in ('binary_checked','binary_solve_performed'):
        rows[key] = as_bool(rows[key])
    require(rows.binary_checked.all(), 'Reference binary checks missing')
    require((rows.binary_solve_performed == (rows.original_overlap_periods>0)).all(),
            'Reference binary flags inconsistent')
    require((rows.binary_objective_gbp <= rows.original_objective_gbp+1e-6).all(),
            'Reference binary objective exceeds the LP objective')
    require(len(replacement)==720, 'Expected 720 replacement asset-period records')
    require(not replacement.duplicated(['schedule','date','asset','period']).any(),
            'Duplicate replacement schedule keys')
    expected=set(map(tuple,rows.loc[rows.binary_solve_performed,['schedule','date']].to_numpy()))
    actual=set(map(tuple,replacement[['schedule','date']].drop_duplicates().to_numpy()))
    require(actual==expected and len(expected)==5, 'Replacement schedule-day coverage differs')
    arrays=load(archive)
    date_index={str(day):k for k,day in enumerate(arrays['dates'])}
    require(set(rows.date)==set(date_index), 'Reference dates differ from baseline')
    require(set(rows.schedule)=={'per','agg'}, 'Unexpected reference schedules')
    max_difference=0.0; max_residual=0.0
    indexed=rows.set_index(['schedule','date'])
    for key,label in [('per','P|W|R'),('agg','PWR')]:
        for day,k in date_index.items():
            record=indexed.loc[(key,day)]
            c=arrays[key+'c'][k].copy(); g=arrays[key+'g'][k].copy()
            original=audit(c,g,arrays['p'][k],arrays['v'][k],PARTS[label])
            require(abs(original['score_gbp']-record.original_score_gbp)<1e-6,
                    f'Original daily score mismatch: {key}, {day}')
            if (key,day) in expected:
                subset=replacement[(replacement.schedule==key)&(replacement.date==day)]
                for i,name in enumerate(NAMES):
                    asset=subset[subset.asset==name].sort_values('period')
                    require(asset.period.tolist()==list(range(1,49)), 'Replacement periods incomplete')
                    c[i]=asset.charge_mw.to_numpy(); g[i]=asset.discharge_mw.to_numpy()
            score=audit(c,g,arrays['p'][k],arrays['v'][k],PARTS[label])
            aggregate=audit(c,g,arrays['p'][k],arrays['v'][k],PARTS['PWR'])
            obj=audit(c,g,arrays['f'][k],arrays['sv'][k],PARTS[label])['score_gbp']
            physical=feasibility(c,g)
            max_residual=max(max_residual,physical['max_violation'])
            require(physical['max_violation']<1e-7 and physical['overlap_periods']==0,
                    f'Invalid reference replacement: {key}, {day}')
            pairs=[(score['score_gbp'],record.binary_score_gbp),
                   (score['gross_gbp'],record.binary_gross_gbp),
                   (score['throughput_mwh'],record.binary_throughput_mwh),
                   (aggregate['score_gbp'],record.binary_aggregate_audit_score_gbp),
                   (obj,record.binary_objective_gbp)]
            difference=max(abs(float(a)-float(b)) for a,b in pairs)
            max_difference=max(max_difference,difference)
            require(difference<1e-6, f'Binary daily reconciliation failed: {key}, {day}')
    return {'reference_daily_records':2162,'replacement_asset_period_records':720,
            'reference_schedule_reconstruction_max_difference':max_difference,
            'reference_reconstructed_max_physical_residual':max_residual}


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--archive',type=Path,default=Path(__file__).resolve().parents[1],
                        help='Extracted baseline analysis directory, including this update.')
    parser.add_argument('--results',type=Path,help='Daily result directory; defaults to paper_of_record.')
    parser.add_argument('--out',type=Path,help='New empty output directory for re-solving or tables.')
    parser.add_argument('--workers',type=int,default=3)
    action=parser.add_mutually_exclusive_group()
    action.add_argument('--validate-stored',action='store_true')
    action.add_argument('--tables',action='store_true',help='Check stored results and recreate tables.')
    parser.add_argument('--surface-only',action='store_true')
    parser.add_argument('--sens-only',action='store_true')
    args=parser.parse_args()
    args.archive=args.archive.resolve()
    if args.validate_stored or args.tables:
        if args.surface_only or args.sens_only:
            parser.error('Partial-family options apply only to re-solving')
        results=(args.results or args.archive/'paper_of_record').resolve()
        if args.tables:
            if args.out is None:
                parser.error('--tables requires --out')
            if args.out.exists() and any(args.out.iterdir()):
                parser.error('Table output directory must be empty')
        elif args.out is not None:
            parser.error('--validate-stored does not write output; omit --out')
        checks=build(args.archive,results,args.out if args.tables else None)
        print(json.dumps(checks,indent=2,allow_nan=False))
    else:
        if args.out is None:
            parser.error('Re-solving requires --out pointing to a new empty directory')
        if args.results is not None:
            parser.error('--results is used only with --validate-stored or --tables')
        run_experiments(args,parser)


if __name__=='__main__':
    main()
